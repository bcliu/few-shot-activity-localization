python main.py something RGB --arch BNInception --num_segments 3 --consensus_type TRN --batch-size 48
